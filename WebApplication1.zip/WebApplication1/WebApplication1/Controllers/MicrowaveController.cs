﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Services.Interfaces;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/microwave")]
    public class MicrowaveController : ControllerBase
    {
        private readonly IMicrowave _microwaveService;

        public MicrowaveController(IMicrowave microwaveService)
        {
            _microwaveService = microwaveService;
        }

        [HttpGet("door/open")]
        public IActionResult OpenDoor()
        {
            var result = _microwaveService.OpenDoor();
            return Ok(result);
        }

        [HttpGet("door/close")]
        public IActionResult CloseDoor()
        {
            var result = _microwaveService.CloseDoor();
            return Ok(result);
        }

        [HttpGet("start/{IsDoorOpen}/{IsHeaterOn}")]
        public IActionResult Start(bool IsDoorOpen , bool IsHeaterOn)
        {
            var result = _microwaveService.StartHeater(IsDoorOpen, IsHeaterOn);
            if (result.Contains("Nothing happens"))
            {
                return BadRequest(result);
            }
            return Ok(result);
        }
    }
}

