﻿using WebApplication1.Services.Interfaces;

namespace WebApplication1.Services.implementations
{
    public class Microwave:IMicrowave
    {
        public bool DoorOpen { get; private set; } = false;
        public bool HeaterOn { get; private set; } = false;
        public int RemainingTime { get; private set; } = 0;

        public string OpenDoor()
        {
            if (HeaterOn)
            {
                HeaterOn = false; // Ensure the heater is off when the door is opened
                return "Heater stoped.";

            }
            DoorOpen = true;
            return "Door opened. Light is on.";
        }

        public string CloseDoor()
        {
            DoorOpen = false;
            return "Door closed. Light is off.";
        }

        public string StartHeater(bool DoorOpen, bool HeaterOn)
        {
            if (DoorOpen)
            {
                return "Nothing happens. Door is open.";
            }

            if (!HeaterOn)
            {
                HeaterOn = true;
                RemainingTime = 60; // 1 minute in seconds
                return "Heater started. Running for 1 minute.";
            }

            RemainingTime += 60; // Increase time by 1 minute
            return "Heater running. Remaining time increased by 1 minute.";
        }
    }
}
