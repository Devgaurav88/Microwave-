﻿namespace WebApplication1.Services.Interfaces
{
    public interface IMicrowave
    {
        bool DoorOpen { get; }
        bool HeaterOn { get; }
        int RemainingTime { get; }
        string OpenDoor();
        string CloseDoor();
        string StartHeater(bool IsDoorOpen , bool IsHeaterOn);
    }
}
