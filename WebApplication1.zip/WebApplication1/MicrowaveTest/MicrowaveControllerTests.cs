﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Moq;
using WebApplication1.Controllers;
using WebApplication1.Services.Interfaces;

namespace MicrowaveTest { 

    public class MicrowaveControllerTests
    {
        private readonly Mock<IMicrowave> _mockMicrowaveService;
        private readonly MicrowaveController _controller;

        public MicrowaveControllerTests()
        {
            _mockMicrowaveService = new Mock<IMicrowave>();
            _controller = new MicrowaveController(_mockMicrowaveService.Object);
        }

        [Fact]
        public void OpenDoor_ReturnsOkWithResult()
        {
            // Arrange
            var expectedResponse = "Door is opened.";
            _mockMicrowaveService.Setup(service => service.OpenDoor()).Returns(expectedResponse);

            // Act
            var result = _controller.OpenDoor();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(expectedResponse, okResult.Value);
        }

        [Fact]
        public void CloseDoor_ReturnsOkWithResult()
        {
            // Arrange
            var expectedResponse = "Door is closed.";
            _mockMicrowaveService.Setup(service => service.CloseDoor()).Returns(expectedResponse);

            // Act
            var result = _controller.CloseDoor();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(expectedResponse, okResult.Value);
        }

        [Theory]
        [InlineData(false, false, "Nothing happens", true)]
        [InlineData(false, true, "Heater started", false)]
        public void Start_ReturnsExpectedResult(bool isDoorOpen, bool isHeaterOn, string expectedResponse, bool isBadRequest)
        {
            // Arrange
            _mockMicrowaveService.Setup(service => service.StartHeater(isDoorOpen, isHeaterOn)).Returns(expectedResponse);

            // Act
            var result = _controller.Start(isDoorOpen, isHeaterOn);

            // Assert
            if (isBadRequest)
            {
                var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
                Assert.Equal(expectedResponse, badRequestResult.Value);
            }
            else
            {
                var okResult = Assert.IsType<OkObjectResult>(result);
                Assert.Equal(expectedResponse, okResult.Value);
            }
        }
    }
}
